import React from "react";

const GitHub = () => {
  return (
    <div>
      <h2>Github</h2>
    </div>
  );
};

export default GitHub;
